import template from './sas-blog-element-preview.html.twig';
import './sas-blog-element-preview.scss';

Shopware.Component.register('sas-blog-el-blog-detail-preview', {
    template,
});
