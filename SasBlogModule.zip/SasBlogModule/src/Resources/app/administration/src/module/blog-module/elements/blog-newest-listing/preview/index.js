import template from './sas-cms-el-preview-newest-listing.html.twig';
import './sas-cms-el-preview-newest-listing.scss';

const { Component } = Shopware;

Component.register('sas-cms-el-preview-newest-listing', {
    template,
});
