import template from './sw-cms-el-preview-blog-single-select.html.twig';
import './sw-cms-el-preview-blog-single-select.scss';

Shopware.Component.register('sw-cms-el-preview-blog-single-select', {
    template,
});
