// <plugin root>/src/Resources/app/administration/src/module/sw-cms/blocks/text-image/gp-achievement/preview/index.js
import template from './sw-cms-preview-gp-achievement.html.twig';
import './sw-cms-preview-gp-achievement.scss';

Shopware.Component.register('sw-cms-preview-gp-achievement', {
    template
});