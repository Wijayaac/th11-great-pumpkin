// <plugin root>/src/Resources/app/administration/src/module/sw-cms/blocks/text-image/gp-video/preview/index.js
import template from './sw-cms-preview-gp-video.html.twig'
import './sw-cms-preview-gp-video.scss'

Shopware.Component.register('sw-cms-preview-gp-video', {
	template,
})