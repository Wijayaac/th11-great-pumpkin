// <plugin root>/src/Resources/app/administration/src/module/sw-cms/blocks/text-image/home-hero/component/index.js
import template from './sw-cms-block-home-hero.html.twig';
import './sw-cms-block-home-hero.scss';

Shopware.Component.register('sw-cms-block-home-hero', {
    template
});