// <plugin root>/src/Resources/app/administration/src/module/sw-cms/blocks/text-image/home-hero/preview/index.js
import template from './sw-cms-preview-home-hero.html.twig';
import './sw-cms-preview-home-hero.scss';

Shopware.Component.register('sw-cms-preview-home-hero', {
    template
});