<?php declare(strict_types=1);

namespace ThStarterTheme;

use Shopware\Core\Framework\Plugin;
use Shopware\Storefront\Framework\ThemeInterface;

class ThStarterTheme extends Plugin implements ThemeInterface
{
}