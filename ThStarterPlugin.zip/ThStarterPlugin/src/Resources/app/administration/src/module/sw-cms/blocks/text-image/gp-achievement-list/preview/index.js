// <plugin root>/src/Resources/app/administration/src/module/sw-cms/blocks/text-image/gp-achievement-list/preview/index.js
import template from './sw-cms-preview-gp-achievement-list.html.twig'
import './sw-cms-preview-gp-achievement-list.scss'

Shopware.Component.register('sw-cms-preview-gp-achievement-list', {
	template
})