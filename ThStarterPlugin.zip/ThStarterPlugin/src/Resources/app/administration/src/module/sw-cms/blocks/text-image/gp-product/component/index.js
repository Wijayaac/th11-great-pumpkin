// <plugin root>/src/Resources/app/administration/src/module/sw-cms/blocks/text-image/home-hero/component/index.js
import template from './sw-cms-block-gp-product.html.twig';
import './sw-cms-block-gp-product.scss';

Shopware.Component.register('sw-cms-block-gp-product', {
    template
});