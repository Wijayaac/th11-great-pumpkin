// <plugin root>/src/Resources/app/administration/src/module/sw-cms/blocks/text-image/gp-contact/preview/index.js
import template from './sw-cms-preview-gp-contact.html.twig'
import './sw-cms-preview-gp-contact.scss'

Shopware.Component.register('sw-cms-preview-gp-contact', {
	template
})